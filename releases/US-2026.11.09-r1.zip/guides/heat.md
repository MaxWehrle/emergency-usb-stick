# Extreme heat

Find a cooler place, reduce activity, and check on people at higher risk.

## What to do

1. Follow National Weather Service heat alerts for your area. Avoid strenuous outdoor activity during the hottest hours.
2. Drink water regularly unless a clinician has told you to limit fluids. Find shade or air conditioning.
3. Check on older adults, children, and people with health conditions. Never leave people or pets in a parked car.
4. For severe symptoms such as confusion or loss of consciousness, call 911.

Reviewed: 2026-11-09 · time-sensitive
Source IDs: NWS-HEAT, NWS-HEAT-ALERTS, US-911
Details and original sources: ../SOURCES.md
