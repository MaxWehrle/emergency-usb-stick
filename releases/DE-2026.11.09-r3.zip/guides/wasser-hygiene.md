# Wasser und Hygiene

Bei Ausfall oder Warnung die Hinweise des örtlichen Versorgers und Gesundheitsamts beachten.

## Was jetzt hilft

1. Nutzen Sie vorhandenes sicheres Trinkwasser sparsam. Halten Sie einen persönlichen Vorrat bereit; Bedarf hängt von Personen, Gesundheit und Dauer ab.
2. Bei einer amtlichen Abkoch- oder Nichttrinken-Anordnung gelten genau deren Vorgaben. Unbekanntes Wasser nicht allein durch Aussehen beurteilen.
3. Planen Sie Handhygiene und Toilettennutzung bei fehlendem Leitungswasser. Seife, Feuchttücher, Müllbeutel und Hygieneartikel helfen.
4. Fragen Sie bei besonderem medizinischem Bedarf frühzeitig nach örtlicher Hilfe.

Prüfstand: 2026-11-09 · Art: zeitkritisch
Quellenkennungen: BBK-WATER, BBK-HYGIENE, BMG-WATER
Details und Originalquellen: ../SOURCES.md
